import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import {environment} from '../../../environments/environment';
import {Consultation} from '../model/consultation';



@Injectable({
  providedIn: 'root'
})
export class ConsultationService {

  private url = environment.baseUrl + '/consultation';
  constructor(private httpClient: HttpClient) { }
  public getAll(): Observable<Consultation[]> {
    return this.httpClient.get<Consultation[]>(this.url);
  }

  public save(consultation: Consultation): Observable<any>{
    return this.httpClient.post(this.url, consultation);
  }

  public update(consultation: Consultation): Observable<any>{
    return this.httpClient.put(this.url, consultation);
  }

  public delete(id): Observable<any>{
    return this.httpClient.delete(this.url + '/' + id);
  }

}

