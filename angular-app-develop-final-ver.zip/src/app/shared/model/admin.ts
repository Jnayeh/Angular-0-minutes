import { Person } from './person';

export class Admin  extends Person{
}
