import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-paging',
  templateUrl: './admin-paging.component.html',
  styleUrls: ['./admin-paging.component.css']
})
export class AdminPagingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
